import csv, json, re, subprocess, math
from pathlib import Path
from faster_whisper import WhisperModel

ROOT = Path.cwd()
INPUT = ROOT / "input"
OUTPUT = ROOT / "output"
OUTPUT.mkdir(exist_ok=True)

HYPE_WORDS = {
    "wow": 1.4, "what": 0.8, "no way": 2.0, "insane": 1.8,
    "crazy": 1.3, "lets go": 1.8, "let's go": 1.8, "unbelievable": 1.8,
    "finally": 1.0, "clutch": 1.5, "incredible": 1.5, "winner": 0.8,
    "amazing": 1.1, "bro": 0.2, "oh my": 1.0
}

def run(cmd):
    subprocess.run(cmd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

def duration_seconds(path):
    out = subprocess.check_output([
        "ffprobe", "-v", "error", "-show_entries", "format=duration",
        "-of", "default=noprint_wrappers=1:nokey=1", str(path)
    ], text=True).strip()
    return float(out)

def transcribe(path, model_size="base"):
    model = WhisperModel(model_size, device="cpu", compute_type="int8")
    segments, _ = model.transcribe(str(path), word_timestamps=False, vad_filter=True)
    return [{"start": float(s.start), "end": float(s.end), "text": s.text.strip()}
            for s in segments if s.text.strip()]

def score_windows(segments, duration, clip_len=35, step=10):
    candidates = []
    start = 0.0
    while start < duration:
        end = min(duration, start + clip_len)
        text = " ".join(s["text"] for s in segments
                        if s["end"] >= start and s["start"] <= end)
        low = text.lower()
        score = sum(weight for phrase, weight in HYPE_WORDS.items() if phrase in low)
        # Prefer windows with speech and a little variation; avoid silent/empty windows.
        speech = sum(max(0, min(end, s["end"]) - max(start, s["start"]))
                     for s in segments if s["end"] >= start and s["start"] <= end)
        score += min(speech / max(clip_len, 1), 1.0) * 0.8
        if text.strip():
            candidates.append({"start": start, "end": end, "score": round(score, 3),
                               "transcript": text})
        start += step
    candidates.sort(key=lambda x: x["score"], reverse=True)
    chosen = []
    for c in candidates:
        if all(abs(c["start"] - x["start"]) >= clip_len * 0.65 for x in chosen):
            chosen.append(c)
        if len(chosen) >= 8:
            break
    return sorted(chosen, key=lambda x: x["start"])

def srt_time(seconds):
    ms = int(seconds * 1000)
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02}:{m:02}:{s:02},{ms:03}"

def write_srt(segments, start, end, out_path):
    rows, idx = [], 1
    for s in segments:
        if s["end"] < start or s["start"] > end:
            continue
        a, b = max(0, s["start"] - start), min(end, s["end"]) - start
        if b <= a:
            continue
        text = re.sub(r"\s+", " ", s["text"]).replace("-->", "→")
        rows.append(f"{idx}\n{srt_time(a)} --> {srt_time(b)}\n{text}\n")
        idx += 1
    Path(out_path).write_text("\n".join(rows), encoding="utf-8")

def make_vertical(source, start, end, out_path, srt_path):
    # Blurred background + centered original video; readable subtitle burn-in.
    vf = (
        "split=2[bg][fg];"
        "[bg]scale=1080:1920:force_original_aspect_ratio=increase,"
        "crop=1080:1920,boxblur=22:10[blur];"
        "[fg]scale=1080:1920:force_original_aspect_ratio=decrease[front];"
        "[blur][front]overlay=(W-w)/2:(H-h)/2,"
        f"subtitles={str(srt_path).replace(':', r'\\:')}:"
        "force_style='FontName=Arial,FontSize=18,Outline=2,Shadow=1,Alignment=2,MarginV=110'"
    )
    run(["ffmpeg", "-y", "-ss", str(start), "-i", str(source),
         "-t", str(end-start), "-vf", vf, "-c:v", "libx264",
         "-preset", "veryfast", "-crf", "23", "-c:a", "aac",
         "-b:a", "128k", "-movflags", "+faststart", str(out_path)])

def process_all(model_size="base"):
    videos = [p for p in INPUT.iterdir() if p.suffix.lower() in
              {".mp4", ".mov", ".mkv", ".webm"}]
    if not videos:
        raise SystemExit("No videos found. Add an authorized video to input/.")
    queue = []
    for video in videos:
        print(f"Transcribing {video.name} ...")
        segs = transcribe(video, model_size)
        dur = duration_seconds(video)
        moments = score_windows(segs, dur)
        for i, m in enumerate(moments, 1):
            stem = re.sub(r"[^A-Za-z0-9_-]+", "_", video.stem)[:35]
            name = f"{stem}_clip_{i:02d}"
            srt = OUTPUT / f"{name}.srt"
            mp4 = OUTPUT / f"{name}.mp4"
            write_srt(segs, m["start"], m["end"], srt)
            print(f"Rendering {name} ...")
            make_vertical(video, m["start"], m["end"], mp4, srt)
            queue.append({
                "filename": mp4.name, "source": video.name,
                "start_seconds": round(m["start"], 2),
                "end_seconds": round(m["end"], 2),
                "score": m["score"], "suggested_title": m["transcript"][:85],
                "approved": "no"
            })
    with (OUTPUT / "review_queue.csv").open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(queue[0].keys()))
        writer.writeheader()
        writer.writerows(queue)
    print(f"Done. {len(queue)} clips created. Review output/review_queue.csv; all are unapproved.")

if __name__ == "__main__":
    process_all()
