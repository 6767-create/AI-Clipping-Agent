import csv, shutil
from pathlib import Path
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload

SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]
ROOT = Path.cwd()
QUEUE = ROOT / "output" / "review_queue.csv"
APPROVED = ROOT / "approved"
APPROVED.mkdir(exist_ok=True)

def upload_approved():
    secret = ROOT / "client_secret.json"
    if not secret.exists():
        raise FileNotFoundError("Upload client_secret.json from your own Google Cloud OAuth setup.")
    flow = InstalledAppFlow.from_client_secrets_file(str(secret), SCOPES)
    credentials = flow.run_console()
    youtube = build("youtube", "v3", credentials=credentials)
    rows = list(csv.DictReader(QUEUE.open(encoding="utf-8")))
    approved = [r for r in rows if r.get("approved", "").strip().lower() == "yes"]
    if not approved:
        print("No approved clips found. Set approved=yes only after reviewing each clip.")
        return
    for row in approved:
        path = APPROVED / row["filename"]
        if not path.exists():
            source = ROOT / "output" / row["filename"]
            if not source.exists():
                print(f"Missing clip: {row['filename']}")
                continue
            shutil.copy2(source, path)
        title = (row.get("suggested_title") or "Edited highlight").replace("\n", " ")[:95]
        body = youtube.videos().insert(
            part="snippet,status",
            body={
                "snippet": {"title": title, "description":
                    "Edited highlight. Source used with permission.",
                    "categoryId": "20"},
                "status": {"privacyStatus": "private",
                           "selfDeclaredMadeForKids": False}
            },
            media_body=MediaFileUpload(str(path), mimetype="video/mp4",
                                       resumable=True)
        ).execute()
        print("Uploaded as PRIVATE draft:", body.get("id"))
    print("Uploads are PRIVATE. Review them in YouTube Studio before making public.")

if __name__ == "__main__":
    upload_approved()
