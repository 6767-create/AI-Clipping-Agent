# AI Clipping Agent — free Colab starter

This project turns **video files you are allowed to use** into short vertical clips:
1. Transcribes the video with Whisper.
2. Scores interesting moments using transcript cues and audio energy.
3. Creates vertical 9:16 clips with captions using FFmpeg.
4. Writes a review list. Nothing is published automatically until you approve it.
5. Uploads only approved clips when you run the YouTube upload step and authorize your own channel.

## Important source and publishing rules
- Use your own streams/videos, creator-authorized downloads, or content with a license that permits editing and reposting.
- A public Twitch or YouTube URL does **not** automatically grant permission to download, edit, or repost it.
- This starter deliberately does not scrape or download arbitrary YouTube/Twitch streams. Put authorized video files in `input/`.
- Keep approval enabled. Check the clip, captions, audio, and rights before publishing.
- YouTube uploads require your own Google OAuth consent and API project. The free quota and account rules may limit uploads.

## Run it on an Android tablet (no paid hosting)
1. Open the GitHub repository `AI-Clipping-Agent` and upload/extract this ZIP into it.
2. Open [Google Colab](https://colab.research.google.com/), sign in, and create a notebook.
3. Upload `AI_Clipping_Agent_Colab.ipynb` from this folder to Colab, or open it from GitHub.
4. In Colab, run the cells from top to bottom. Upload only video files you have permission to use when prompted.
5. Open `output/review_queue.csv` and inspect the generated clips.
6. To approve a clip, set its `approved` value to `yes` in the CSV, then run the optional upload cell after setting up YouTube API access.

Colab sessions are temporary and may disconnect. Save output clips and the review CSV to your own Google Drive before closing the session.

## YouTube API setup (optional)
Create a Google Cloud project, enable **YouTube Data API v3**, configure the OAuth consent screen, and create an OAuth client suitable for a desktop app. Download the OAuth client JSON as `client_secret.json` and upload it to the Colab session only when running the upload cell. Never commit that file, access tokens, API keys, or passwords to GitHub.

## Folder layout
- `input/` — authorized source videos
- `output/` — generated clips and review queue
- `approved/` — clips you have reviewed and approved
- `src/` — processing and upload code
- `AI_Clipping_Agent_Colab.ipynb` — tablet-friendly Colab workflow
